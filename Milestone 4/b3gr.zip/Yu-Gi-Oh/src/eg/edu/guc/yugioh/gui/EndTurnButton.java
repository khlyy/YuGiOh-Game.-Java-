package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;

import javax.swing.JButton;

public class EndTurnButton extends JButton{

	public EndTurnButton() {
		super();
		setPreferredSize(new Dimension( 100, 53));
		//setLabel("END TURN");
	}

}
