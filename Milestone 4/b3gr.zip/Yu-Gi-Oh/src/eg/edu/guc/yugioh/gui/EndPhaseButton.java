package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;

import javax.swing.JButton;

public class EndPhaseButton extends JButton {

	public EndPhaseButton() {
		super();
		setPreferredSize(new Dimension( 100, 53));
		// TODO Auto-generated constructor stub
	}

}
