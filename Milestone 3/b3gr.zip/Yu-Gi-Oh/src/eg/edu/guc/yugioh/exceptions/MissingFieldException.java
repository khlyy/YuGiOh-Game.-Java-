package eg.edu.guc.yugioh.exceptions;

public class MissingFieldException extends UnexpectedFormatException {

	public MissingFieldException(String m , int n){
		super(m,n);
	}


}
