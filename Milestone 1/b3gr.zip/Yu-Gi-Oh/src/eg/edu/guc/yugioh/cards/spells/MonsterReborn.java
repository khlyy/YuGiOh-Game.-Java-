package eg.edu.guc.yugioh.cards.spells;

import java.io.IOException;
import java.util.ArrayList;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.Location;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class MonsterReborn extends SpellCard{

	public MonsterReborn(String name, String description) {
		super(name, description);
		// TODO Auto-generated constructor stub
	}
	public void action(MonsterCard monster) throws IOException {
		int max = 0 ;
		MonsterCard m = null;
		int sizeActive = getBoard().getActivePlayer().getField().getGraveyard().size();
		int sizeOppo= getBoard().getOpponentPlayer().getField().getGraveyard().size();
		int totalSize = sizeActive+sizeOppo;
		ArrayList<Card> active = getBoard().getActivePlayer().getField().getGraveyard();
		ArrayList<Card> oppo = getBoard().getOpponentPlayer().getField().getGraveyard();
		ArrayList<MonsterCard> total = new ArrayList<MonsterCard>();
		for (int i = 0; i <sizeOppo ; i++) {
			if(oppo!=null){
			if (oppo.get(i) instanceof MonsterCard )
				total.add((MonsterCard) oppo.get(i));
		}
		}
		for (int i = 0; i <sizeActive ; i++) {
			if(active!=null){
			if (active.get(i) instanceof MonsterCard )
				total.add((MonsterCard) active.get(i));
		}
		}
		for (int i = 0; i < total.size(); i++) {
			if(total!=null){
			if(total.get(i).getAttackPoints() > max){
				max = total.get(i).getAttackPoints();
				m = total.get(i);
			}
			}
		}
			if(m!=null){
			m.setLocation(Location.FIELD);
			getBoard().getActivePlayer().getField().getGraveyard().remove(m);
			getBoard().getOpponentPlayer().getField().getGraveyard().remove(m);

			getBoard().getActivePlayer().getField().addMonsterToField(m, m.getMode(), m.isHidden());
		}
		
	}
}

