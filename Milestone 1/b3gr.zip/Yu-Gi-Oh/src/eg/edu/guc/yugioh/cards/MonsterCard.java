package eg.edu.guc.yugioh.cards;

public class MonsterCard extends Card{

	private	int level ;
	private	int defensePoints ;
	private	int attackPoints ;
	private	Mode mode ;
	
	public MonsterCard(String name, String description, int level, int attack ,int defence) {
		super(name, description);
		this.level = level ;
		this.defensePoints = defence;
		this.attackPoints = attack ;
		mode = mode.DEFENSE;
		// TODO Auto-generated constructor stub
	}

	public int getLevel() {
		return level;
	}

	public int getDefensePoints() {
		return defensePoints;
	}

	public void setDefensePoints(int defensePoint) {
		this.defensePoints = defensePoint;
	}

	public int getAttackPoints() {
		return attackPoints;
	}

	public void setAttackPoints(int attackPoint) {
		this.attackPoints = attackPoint;
	}

	public Mode getMode() {
		return mode;
	}

	public void setMode(Mode mode) {
		this.mode = mode;
	}
	

}
