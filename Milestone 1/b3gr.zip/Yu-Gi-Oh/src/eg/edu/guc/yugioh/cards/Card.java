package eg.edu.guc.yugioh.cards;

import java.io.IOException;

import eg.edu.guc.yugioh.board.Board;

public class Card {

	private String name;
	private String description;
	private boolean isHidden;
	private Location location;
	private static  Board board;

	/*public Card(String name, String description, boolean isHidden,
			Location location, Board board) {
		this.name = name;
		this.description = description;
		this.isHidden = isHidden;
		this.location = location;
		this.board = board;

	}*/

	public Card(String name, String description) {

		this.name = name;
		this.description = description;
		this.isHidden = true;
		this.location = location.DECK;
	}
	
	public static Board getBoard() {
		return board;
	}

	public static void setBoard(Board board) {
		 Card.board = board;
	}

	

	public void action(MonsterCard monster) throws IOException {

	}

	public boolean isHidden() {
		return isHidden;
	}

	public void setHidden(boolean isHidden) {
		this.isHidden = isHidden;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

}
