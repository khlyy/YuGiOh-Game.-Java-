package eg.edu.guc.yugioh.board.player;

import java.io.IOException;

public class Player {
	
	private	String name;
	private int lifePoints ;
	private Field field;

public Player (String name) throws IOException{
	this.name = name ;
	lifePoints = 8000;
	field = new Field();
}

public int getLifePoints() {
	return lifePoints;
}

public void setLifePoints(int lifePoint) {
	this.lifePoints = lifePoint;
}

public String getName() {
	return name;
}

public Field getField() {
	return field;
}


}
