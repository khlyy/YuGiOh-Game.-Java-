package eg.edu.guc.yugioh.cards.spells;

import eg.edu.guc.yugioh.cards.Card;

public class SpellCard extends Card  {

	public SpellCard(String name, String description) {
		super(name, description);
		// TODO Auto-generated constructor stub
	}

}
