package eg.edu.guc.yugioh.board.player;

public enum Phase {
	MAIN1, BATTLE, MAIN2 ;
}
